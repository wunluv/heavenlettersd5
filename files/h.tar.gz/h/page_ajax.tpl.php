<head>
<style>
.normal {
clear:both;
padding:5px 0;
}
legend {
color:#B79715;
font-size:1.2em;
}
.normal select,
.normal label,
.normal input {
float:left;
font-family:georgia,arial;
font-size:1.2em;
width:130px !important;
}
.normal input,
.normal select {
width:auto;
margin:0 0 0 5px;
}
</style>
<style type="text/css" media="all">@import "/heaven/sites/all/themes/h/style.css";</style>
</head>
<?php print  $content;  ?>